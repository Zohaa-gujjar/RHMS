import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Interface for notification capabilities
interface Notifiable {
    void sendNotification(String recipient, String message);
    boolean isDelivered();
}

// Email Notification Implementation
class EmailNotification implements Notifiable {
    private String serverAddress;
    private boolean delivered;

    public EmailNotification(String serverAddress) {
        this.serverAddress = serverAddress;
        this.delivered = false;
    }

    @Override
    public void sendNotification(String recipient, String message) {
        try {
            // Simulate sending an email
            System.out.println("Sending email to " + recipient);
            System.out.println("Message: " + message);
            //System.out.println("Using server: " + serverAddress);
            delivered = true;
        } catch (Exception e) {
            delivered = false;
            System.err.println("Sending e-mail failed: " + e.getMessage());
        }
    }

    @Override
    public boolean isDelivered() {
        return delivered;
    }
}

// SMS Notification Implementation
class SMSNotification implements Notifiable {
    private String gatewayProvider;
    private boolean delivered;

    public SMSNotification(String gatewayProvider) {
        this.gatewayProvider = gatewayProvider;
        this.delivered = false;
    }

    @Override
    public void sendNotification(String recipient, String message) {
        try {
            // Simulate sending an SMS
            System.out.println("SMS sent to " + recipient);
            System.out.println("Message: " + message);
            //System.out.println("Using gateway: " + gatewayProvider);
            delivered = true;
        } catch (Exception e) {
            delivered = false;
            System.err.println("Sending SMS Failed: " + e.getMessage());
        }
    }

    @Override
    public boolean isDelivered() {
        return delivered;
    }
}

// Base Notification Service
abstract class NotificationService {
    protected Notifiable notifier;

    public NotificationService(Notifiable notifier) {
        this.notifier = notifier;
    }

    public abstract void notify(String recipient, String message);
}

// Emergency Alert System
class EmergencyAlert extends NotificationService {
    private int criticalHeartRate;
    private int criticalBloodPressure;
    private int criticalOxygenLevel;
    private int criticalRespiratoryRate;

    public EmergencyAlert(Notifiable notifier, int criticalHeartRate,
                          int criticalBloodPressure, int criticalOxygenLevel, int criticalRespiratoryRate) {
        super(notifier);
        this.criticalHeartRate = criticalHeartRate;
        this.criticalBloodPressure = criticalBloodPressure;
        this.criticalOxygenLevel = criticalOxygenLevel;
        this.criticalRespiratoryRate = criticalRespiratoryRate;
    }

    public void checkVitals(int heartRate, int bloodPressure, int oxygenLevel, int respiratoryRate) {
        boolean isCritical = false;
        StringBuilder alertMessage = new StringBuilder("EMERGENCY CONDITION ALERT: ");

        if (heartRate > criticalHeartRate) {
            alertMessage.append("Heart rate critical at ").append(heartRate).append("bpm. ");
            isCritical = true;
        }

        if (bloodPressure > criticalBloodPressure) {
            alertMessage.append("Blood pressure critical at ").append(bloodPressure).append("mmHg. ");
            isCritical = true;
        }

        if (oxygenLevel < criticalOxygenLevel) {
            alertMessage.append("Oxygen levels critical at ").append(oxygenLevel).append("%. ");
            isCritical = true;
        }
        if (respiratoryRate > criticalRespiratoryRate) {
            alertMessage.append("Breathing levels critical at ").append(respiratoryRate).append("times/min. ");
            isCritical = true;
        }

        if (isCritical) {
            alertMessage.append("Patient is unfit, immediate attention is required!");
            triggerAlert(alertMessage.toString());
        }
    }

    private void triggerAlert(String alertMessage) {
        try {
            // Alert emergency contacts and medical staff
            System.out.println("ACTIVATING EMERGENCY PROTOCOL");
            notify("emergency@hospital.com", alertMessage);
        } catch (Exception e) {
            System.err.println("Failed to activate emergency alert: " + e.getMessage());
        }
    }

    @Override
    public void notify(String recipient, String message) {
        notifier.sendNotification(recipient, message);
    }
}

// Panic Button for manual alerts
class PanicButton {
    private EmergencyAlert emergencySystem;
    private String patientName;
    private String patientId;

    public PanicButton(EmergencyAlert emergencySystem, String patientName, String patientId) {
        this.emergencySystem = emergencySystem;
        this.patientName = patientName;
        this.patientId = patientId;
    }

    public void press() {
        String message =  patientName + "HAS PRESSED  PANIC BUTTON " +
                " Immediately attend the patient! ";
        try {
            System.out.println("Panic button activated!");
            emergencySystem.notify("emergency@hospital.com", message);
        } catch (Exception e) {
            System.err.println("Failed to process panic button press: " + e.getMessage());
        }
    }
}

// Reminder Service for appointments and medications
// Reminder Service for appointments and medications
class ReminderService extends NotificationService {
    private Map<String, List<String>> patientReminders;

    public ReminderService(Notifiable notifier) {
        super(notifier);
        patientReminders = new HashMap<>();
    }

    public void addReminder(String patientId, String reminder) {
        if (!patientReminders.containsKey(patientId)) {
            patientReminders.put(patientId, new ArrayList<>());
        }
        patientReminders.get(patientId).add(reminder);
    }

    public void sendReminders(String patientId, String contactInfo) {
        if (patientReminders.containsKey(patientId)) {
            StringBuilder message = new StringBuilder("Reminder For Patient :\n");
            for (String reminder : patientReminders.get(patientId)) {
                message.append("- ").append(reminder).append("\n");
            }
            notify(contactInfo, message.toString());
        } else {
            System.out.println("No reminders found for patient ID: " + patientId);
        }
    }

    @Override
    public void notify(String recipient, String message) {
        notifier.sendNotification(recipient, message);
    }
}

// Chat related classes
abstract class ChatUser {
    protected String userId;
    protected String name;

    public ChatUser(String userId, String name) {
        this.userId = userId;
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }
}

// Chat Server to handle messaging
class ChatServer {
    private Map<String, ChatUser> connectedUsers;
    private List<String> messageHistory;

    public ChatServer() {
        connectedUsers = new HashMap<>();
        messageHistory = new ArrayList<>();
    }

    public void registerUser(ChatUser user) {
        connectedUsers.put(user.getUserId(), user);
        System.out.println("User " + user.getName() + " registered with server.");
    }

    public void removeUser(String userId) {
        if (connectedUsers.containsKey(userId)) {
            System.out.println("User " + connectedUsers.get(userId).getName() + " disconnected from server.");
            connectedUsers.remove(userId);
        }
    }

    public void broadcastMessage(String senderId, String message) throws Exception {
        if (!connectedUsers.containsKey(senderId)) {
            throw new Exception("Sender not registered with chat server");
        }

        String formattedMessage = connectedUsers.get(senderId).getName() + ": " + message;
        messageHistory.add(formattedMessage);

        System.out.println("BROADCAST: " + formattedMessage);
        // In a real implementation, this would send to all connected clients
    }

    public void sendPrivateMessage(String senderId, String receiverId, String message) throws Exception {
        if (!connectedUsers.containsKey(senderId)) {
            throw new Exception("Sender not registered with chat server");
        }

        if (!connectedUsers.containsKey(receiverId)) {
            throw new Exception("Receiver not found");
        }

        String formattedMessage = "PRIVATE - " + connectedUsers.get(senderId).getName() +
                " to " + connectedUsers.get(receiverId).getName() +
                ": " + message;
        messageHistory.add(formattedMessage);

        System.out.println(formattedMessage);
        // In a real implementation, this would send only to the specified client
    }

    public List<String> getRecentMessages(int count) {
        int start = Math.max(0, messageHistory.size() - count);
        return messageHistory.subList(start, messageHistory.size());
    }
}

// Chat Client implementation
class ChatClient {
    private ChatUser user;
    private ChatServer server;
    private boolean connected;

    public ChatClient(ChatUser user, ChatServer server) {
        this.user = user;
        this.server = server;
        this.connected = false;
    }

    public void connect() {
        server.registerUser(user);
        connected = true;
        System.out.println(user.getName() + " connected to chat server.");
    }

    public void disconnect() {
        if (connected) {
            server.removeUser(user.getUserId());
            connected = false;
            System.out.println(user.getName() + " disconnected from chat server.");
        }
    }

    public void sendMessage(String message) throws Exception {
        if (!connected) {
            throw new Exception("Not connected to server");
        }
        server.broadcastMessage(user.getUserId(), message);
    }

    public void sendPrivateMessage(String receiverId, String message) throws Exception {
        if (!connected) {
            throw new Exception("Not connected to server");
        }
        server.sendPrivateMessage(user.getUserId(), receiverId, message);
    }

    public List<String> getRecentMessages(int count) {
        return server.getRecentMessages(count);
    }
}

// Video call functionality
class VideoCall {
    private String meetingPlatform;
    private String meetingId;
    private String password;
    private boolean active;

    public VideoCall(String meetingPlatform) {
        this.meetingPlatform = meetingPlatform;
        this.active = false;
    }

    public void initiate(String doctorId, String patientId) {
        meetingId = generateMeetingId(doctorId, patientId);
        password = generatePassword();
        active = true;

        System.out.println("Video call initiated on " + meetingPlatform);
        System.out.println("Meeting ID: " + meetingId);
        System.out.println("Password: " + password);
    }

    public String getMeetingLink() {
        if (!active) {
            return null;
        }

        if (meetingPlatform.equalsIgnoreCase("zoom")) {
            return "https://zoom.us/j/" + meetingId + "?pwd=" + password;
        } else if (meetingPlatform.equalsIgnoreCase("google meet")) {
            return "https://meet.google.com/" + meetingId;
        } else {
            return "Unknown platform";
        }
    }

    public void endCall() {
        if (active) {
            System.out.println("Ending video call: " + meetingId);
            active = false;
        }
    }

    private String generateMeetingId(String doctorId, String patientId) {
        // In a real application, this would generate a unique meeting ID
        return "meeting-" + doctorId.substring(0, 3) + "-" + patientId.substring(0, 3) +
                "-" + System.currentTimeMillis() % 10000;
    }

    private String generatePassword() {
        // In a real application, this would generate a secure password
        return "pass" + (int)(Math.random() * 10000);
    }

    public boolean isActive() {
        return active;
    }
}

// Main class - must be in a file named RemotePatientMonitoringSystem.java
public  class RemotePatientMonitoringSystem {
    public static void main(String[] args) {
        try {
            // Set up notification systems
            EmailNotification emailNotifier = new EmailNotification("shifa.hospital.com");
            SMSNotification smsNotifier = new SMSNotification("twilio");

            // Set up emergency alert system
            EmergencyAlert emergencySystem = new EmergencyAlert(smsNotifier, 120, 160, 90, 5);

            // Create panic button for a patient
            PanicButton panicButton = new PanicButton(emergencySystem, "John Doe", "P1");

            // Set up reminder service
            // Set up reminder service
            ReminderService reminderService = new ReminderService(emailNotifier);
            reminderService.addReminder("P1", "Inject Insulin for sugar level control.");
            reminderService.addReminder("P1", "Therapist checkup scheduled at 1 pm today.");

// Send reminders to patient
            reminderService.sendReminders("P1", "patient1@gmail.com.com");

            // Test emergency alert system with critical vitals
            System.out.println("\nTesting emergency alert with critical vitals:");
            emergencySystem.checkVitals(130, 170, 85, 4);

            // Test panic button
            System.out.println("\nTesting panic button:");
            panicButton.press();

            // Set up chat system
            System.out.println("\nSetting up chat system:");
            ChatServer chatServer = new ChatServer();

            // Create doctor and patient chat users
            ChatUser doctorUser = new ChatUser("D1", "Dr. Zohaa") {};
            ChatUser patientUser = new ChatUser("P1", "John Doe") {};

            // Create chat clients
            ChatClient doctorClient = new ChatClient(doctorUser, chatServer);
            ChatClient patientClient = new ChatClient(patientUser, chatServer);

            // Connect to chat
            doctorClient.connect();
            patientClient.connect();

            // Send messages
            doctorClient.sendMessage("Dear John, what is the status of you pain after yesterdays medication.");
            patientClient.sendMessage("The pain feels much releived, although there is a sense of lethargic feeling.");

            // Private message
            doctorClient.sendPrivateMessage("P1", "I've reviewed your latest test results.");

            // List recent messages
            System.out.println("\nRecent chat messages:");
            for (String message : chatServer.getRecentMessages(10)) {
                System.out.println(message);
            }

            // Video call
            System.out.println("\nInitiating video call:");
            VideoCall videoCall = new VideoCall("Zoom");
            videoCall.initiate("D1", "P1");
            System.out.println("Meeting link: " + videoCall.getMeetingLink());
            videoCall.endCall();

        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}